const express = require("express");
const router = express.Router();
const Pet = require("../models/Pet");

// Get all pets
router.get("/", async (req, res) => {
    try {
        const pets = await Pet.find();
        res.status(200).json(pets);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Add a new pet
router.post("/", async (req, res) => {
    const { name, breed, age, description, adopted } = req.body;
    try {
        const newPet = new Pet({ name, breed, age, description, adopted });
        await newPet.save();
        res.status(201).json(newPet);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// Update a pet
router.put("/:id", async (req, res) => {
    const { id } = req.params;
    const { name, breed, age, description, adopted } = req.body;
    try {
        const updatedPet = await Pet.findByIdAndUpdate(
            id,
            { name, breed, age, description, adopted },
            { new: true }
        );
        res.status(200).json(updatedPet);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// Delete a pet
router.delete("/:id", async (req, res) => {
    const { id } = req.params;
    try {
        await Pet.findByIdAndDelete(id);
        res.status(200).json({ message: "Pet deleted successfully" });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

module.exports = router;