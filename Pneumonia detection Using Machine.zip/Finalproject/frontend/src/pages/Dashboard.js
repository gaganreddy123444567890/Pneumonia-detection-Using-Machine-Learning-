import React, { useState, useEffect } from "react";
import axios from "axios";
import {
    Container,
    Typography,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    TextField,
} from "@mui/material";

const Dashboard = () => {
    const [pets, setPets] = useState([]);
    const [open, setOpen] = useState(false);
    const [currentPet, setCurrentPet] = useState({
        name: "",
        breed: "",
        age: "",
        description: "",
    });
    const [isEditing, setIsEditing] = useState(false);

    useEffect(() => {
        fetchPets();
    }, []);

    const fetchPets = async () => {
        try {
            const response = await axios.get("http://localhost:5000/api/pets");
            setPets(response.data);
        } catch (error) {
            console.error("Error fetching pets:", error);
        }
    };

    const handleOpen = () => setOpen(true);
    const handleClose = () => {
        setOpen(false);
        setCurrentPet({ name: "", breed: "", age: "", description: "" });
        setIsEditing(false);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setCurrentPet({ ...currentPet, [name]: value });
    };

    const handleAddOrUpdate = async () => {
        if (isEditing) {
            // Update pet
            try {
                await axios.put('http://localhost:5000/api/pets/${currentPet._id}, currentPet');
                fetchPets();
                handleClose();
            } catch (error) {
                console.error("Error updating pet:", error);
            }
        } else {
            // Add pet
            try {
                await axios.post("http://localhost:5000/api/pets", currentPet);
                fetchPets();
                handleClose();
            } catch (error) {
                console.error("Error adding pet:", error);
            }
        }
    };

    const handleEdit = (pet) => {
        setCurrentPet(pet);
        setIsEditing(true);
        handleOpen();
    };

    const handleDelete = async (id) => {
        try {
            await axios.delete('http://localhost:5000/api/pets/${id}');
            fetchPets();
        } catch (error) {
            console.error("Error deleting pet:", error);
        }
    };

    return (
        <Container>
            <Typography variant="h3" align="center" marginY={4}>
                Pet Management Dashboard
            </Typography>
            <Button variant="contained" color="primary" onClick={handleOpen}>
                Add New Pet
            </Button>
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Name</TableCell>
                            <TableCell>Breed</TableCell>
                            <TableCell>Age</TableCell>
                            <TableCell>Description</TableCell>
                            <TableCell>Adopted</TableCell>
                            <TableCell>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {pets.map((pet) => (
                            <TableRow key={pet._id}>
                                <TableCell>{pet.name}</TableCell>
                                <TableCell>{pet.breed}</TableCell>
                                <TableCell>{pet.age}</TableCell>
                                <TableCell>{pet.description}</TableCell>
                                <TableCell>{pet.adopted ? "Yes" : "No"}</TableCell>
                                <TableCell>
                                    <Button
                                        variant="outlined"
                                        color="primary"
                                        onClick={() => handleEdit(pet)}
                                    >
                                        Edit
                                    </Button>
                                    <Button
                                        variant="outlined"
                                        color="secondary"
                                        onClick={() => handleDelete(pet._id)}
                                        style={{ marginLeft: "10px" }}
                                    >
                                        Delete
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>

            {/* Dialog for Adding/Editing */}
            <Dialog open={open} onClose={handleClose}>
                <DialogTitle>{isEditing ? "Edit Pet" : "Add New Pet"}</DialogTitle>
                <DialogContent>
                    <TextField
                        fullWidth
                        label="Name"
                        name="name"
                        value={currentPet.name}
                        onChange={handleChange}
                        margin="dense"
                    />
                    <TextField
                        fullWidth
                        label="Breed"
                        name="breed"
                        value={currentPet.breed}
                        onChange={handleChange}
                        margin="dense"
                    />
                    <TextField
                        fullWidth
                        label="Age"
                        name="age"
                        type="number"
                        value={currentPet.age}
                        onChange={handleChange}
                        margin="dense"
                    />
                    <TextField
                        fullWidth
                        label="Description"
                        name="description"
                        value={currentPet.description}
                        onChange={handleChange}
                        margin="dense"
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose} color="secondary">
                        Cancel
                    </Button>
                    <Button onClick={handleAddOrUpdate} color="primary">
                        {isEditing ? "Update" : "Add"}
                    </Button>
                </DialogActions>
            </Dialog>
        </Container>
    );
};

export default Dashboard;