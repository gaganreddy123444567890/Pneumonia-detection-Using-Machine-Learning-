import React, { useState, useEffect } from "react";
import axios from "axios";
import { Container, Grid, Card, CardContent, Typography, Button } from "@mui/material";

const Home = () => {
    const [pets, setPets] = useState([]);

    useEffect(() => {
        fetchPets();
    }, []);

    const fetchPets = async () => {
        try {
            const response = await axios.get("http://localhost:5000/api/pets");
            setPets(response.data);
        } catch (error) {
            console.error("Error fetching pets:", error);
        }
    };

    return (
        <Container>
            <Typography variant="h3" align="center" marginY={4}>
                Available Pets for Adoption
            </Typography>
            <Grid container spacing={4}>
                {pets.map((pet) => (
                    <Grid item xs={12} sm={6} md={4} key={pet._id}>
                        <Card>
                            <CardContent>
                                <Typography variant="h5">{pet.name}</Typography>
                                <Typography variant="body1">Breed: {pet.breed}</Typography>
                                <Typography variant="body1">Age: {pet.age} years</Typography>
                                <Typography variant="body2">{pet.description}</Typography>
                                <Typography variant="body2" color={pet.adopted ? "secondary" : "primary"}>
                                    {pet.adopted ? "Adopted" : "Available"}
                                </Typography>
                                <Button
                                    variant="contained"
                                    color="primary"
                                    disabled={pet.adopted}
                                    style={{ marginTop: "10px" }}
                                >
                                    Adopt
                                </Button>
                            </CardContent>
                        </Card>
                    </Grid>
                ))}
            </Grid>
        </Container>
    );
};

export default Home;