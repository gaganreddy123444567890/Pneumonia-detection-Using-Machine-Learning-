import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { TextField, Button, Typography, Container } from "@mui/material";

const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();

    const handleLogin = () => {
        if (email === "admin@example.com" && password === "admin123") {
            navigate("/dashboard");
        } else {
            alert("Invalid credentials");
        }
    };

    return (
        <Container>
            <Typography variant="h4" align="center" marginY={4}>
                Admin Login
            </Typography>
            <TextField
                fullWidth
                label="Email"
                margin="dense"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
            />
            <TextField
                fullWidth
                type="password"
                label="Password"
                margin="dense"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
            />
            <Button
                fullWidth
                variant="contained"
                color="primary"
                onClick={handleLogin}
                style={{ marginTop: "20px" }}
            >
                Login
            </Button>
        </Container>
    );
};

export default Login;